# police-station-db
# policestationdb

To run this project on our local systerm, we need to have a `python` (version 3 or +) and run following command to intall Django framework

`pip install django`

Than navigate to the root folder and open the code in VS Code. than open terminal and run following command

`python manage.py runserver`

And than open your browser and logon to 
`http://127.0.0.1:8000/`

It will ask for login ID and Password
Login ID:  `admin`
Password:  `admin1234`

Samples

![ ](https://github.com/swebreza/policestationdb/blob/main/templates/img/login.png?raw=true)
![ ](https://github.com/swebreza/policestationdb/blob/main/templates/img/register%20page.png?raw=true)
![ ](https://github.com/swebreza/policestationdb/blob/main/templates/img/homepage.png?raw=true)
![ ](https://github.com/swebreza/policestationdb/blob/main/templates/img/criminal.png?raw=true)
![ ](https://github.com/swebreza/policestationdb/blob/main/templates/img/officer.png?raw=true)
![ ](https://github.com/swebreza/policestationdb/blob/main/templates/img/add%20criminal%20record.png?raw=true)
