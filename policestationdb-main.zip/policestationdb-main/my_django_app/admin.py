from django.contrib import admin
from my_django_app.models import hellow
from my_django_app.models import fir
from my_django_app.models import officer

admin.site.register(hellow)
admin.site.register(fir)
admin.site.register(officer)